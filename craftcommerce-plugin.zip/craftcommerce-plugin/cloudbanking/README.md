# CloudBanking Gateway Plugin For Craft CMS

Craft Commerce Quickpay Gateway plugin

## Installation

To install Cloudbanking plugin , follow these steps:

1. Download & unzip the file and place the `cloudbanking` directory into your `craft/plugins` directory
2.  -OR- do a `git clone https://github.com/Pawan82888/cloudbanking-plugin` and place the `cloudbanking` into your `craft/plugins` folder.  You can then update it with `git pull`
3.  -OR- install with Composer.
4. Install plugin in the Craft Control Panel under Settings > Plugins
5. The plugin folder should be named `cloudbanking` for Craft to see it.  GitHub recently started appending `-master` (the branch name) to the name of the folder for zip file downloads.
6. Make sure that you have `composer.phar`. Navigate to the `cloudbanking` directory and run `composer.phar install` 

-NOTE- If Craft Admin panel cannot find the plugin, that might be a permission issues, to solve it, just navigate to the craft/plugins directory and execute the following command in your terminal: `chmod 755 cloudbanking/` 

QuickpayGateway works on Craft 2.4.x and Craft 2.5.x.

## CloudBanking Overview

The following gateways are provided by this package:

* [CloudBanking ](http://cloudbanking.com.au/)

* [CloudBanking](https://quickpay.net/) is a Payment Service Provider that accept all common payment methods - credit cards,and more.
* The Adapter utilizes CloudBnaking payment processor wrapped into Omnipay driver.
* [Omnipay](https://omnipay.thephpleague.com/) is a payment processing library for PHP. 

### Enjoy!