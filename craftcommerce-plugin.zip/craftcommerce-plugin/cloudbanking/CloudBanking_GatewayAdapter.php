<?php
namespace Commerce\Gateways\Omnipay;
use Commerce\Gateways\CreditCardGatewayAdapter;
class CloudBanking_GatewayAdapter extends CreditCardGatewayAdapter
{
    public function handle()
    {
        // This is the omnipay class name compatible with `Omnipay::create`.
        // See https://github.com/thephpleague/omnipay-common/blob/master/src/Omnipay.php#L100-L103
        return "CloudBanking";
    }
}

